# AMVA Android

Projeto Android do aplicativo AMVA – Associação Master Vale do Aço.

Ele abre a versão oficial do AMVA hospedada em:
https://piteradoradorg12.github.io/amva-app/

Características:
- Android 6.0+ (minSdk 23)
- Nome do app: AMVA
- Application ID: br.com.amva.app
- Sem Node.js
- Usa o mesmo Supabase e a mesma versão web
- Pode ser compilado como APK e, posteriormente, AAB

Importante:
- O APK gerado por este projeto é para instalação direta/testes.
- Para Google Play, gerar AAB assinado e cumprir os requisitos da Play Console.
